# Copyright (C) 2023 Crest Data Systems.
# All rights reserved

import json
import re
import time
from datetime import datetime, timedelta, timezone
from typing import Callable, Dict, Iterator, List, Tuple, Union

from datadog_api_client.exceptions import ApiException, ForbiddenException
from datadog_api_client.v1.api.authentication_api import AuthenticationApi
from datadog_api_client.v1.api.metrics_api import MetricsApi
from datadog_api_client.v1.models import MetricContentEncoding
from datadog_api_client.v2 import ApiClient, Configuration
from datadog_api_client.v2.api.logs_api import LogsApi
from datadog_api_client.v2.models import ContentEncoding, LogsSort
from dateutil.parser import parse as dateutil_parser
from urllib3 import make_headers

from . import cds_dell_emc_consts as constants


def utc_time_from_timestamp(timestamp):
    """Coverts timestamp to the UTC datetime string."""
    return datetime.fromtimestamp(timestamp, timezone.utc).strftime(constants.LOGS_TIME_FORMAT)


def replace_special_char_with_underscore(str_to_change):
    """Replaces special characters with underscores."""
    chars_to_match = "[^\\w\\.\\-\\:\\/\\\\]"
    # You can manually specify the number of replacements by changing the 4th argument
    result = re.sub(chars_to_match, "_", str_to_change, count=0, flags=re.MULTILINE)

    return result


class DatadogAPIError(Exception):
    """Base exception class of Datadog API client."""

    def __init__(self, *args: object) -> None:
        super().__init__(*args)


class InvalidAPIKeyError(DatadogAPIError):
    """Raised when API key validation fails."""

    pass


class InvalidKeyError(DatadogAPIError):
    """Raised when API key or app key validation fails."""

    pass


def get_retry_wait_and_message(ex: ApiException, tries: int) -> Tuple[float, str]:
    wait_for = constants.DD_WAIT_FOR
    warn_msg = (
        f"Datadog API error occurred with status code={ex.status},"
        f" retrying for attempt {tries} after default wait time {wait_for} seconds..."
    )
    if ex.headers and ex.headers.get("x-ratelimit-reset"):
        warn_msg = (
            f"Datadog API error occurred with status code={ex.status},"
            f" retrying for attempt {tries} after {wait_for} seconds..."
        )
        wait_for = float(ex.headers["x-ratelimit-reset"])
    return wait_for, warn_msg


def handle_api_exception(ex: ApiException, tries: int) -> Tuple[int, bool, Union[float, None], Union[str, None]]:
    if ex.status in constants.DD_STATUS_TO_RETRY and tries < constants.DD_MAX_TRIES:
        tries += 1
        wait_for, warn_msg = get_retry_wait_and_message(ex, tries)
        return tries, True, wait_for, warn_msg
    return tries, False, None, None


def handle_forbidden_exception(log, ex):
    forbidden_msg = "Received access forbidden error from Datadog API. Verify the configured api key and app key."
    log.exception(forbidden_msg)
    raise InvalidKeyError(forbidden_msg) from ex


def attempt_api_call(func, log, tries, args, kwargs):
    try:
        resp = func(*args, **kwargs)
        return resp, tries, False
    except ForbiddenException as ex:
        handle_forbidden_exception(log, ex)
    except ApiException as ex:
        tries, should_retry, wait_for, warn_msg = handle_api_exception(ex, tries)
        if not should_retry:
            raise
        log.warning(warn_msg)
        time.sleep(wait_for)
        return None, tries, True


def retry_on_api_exception(func):
    """Retries on Datadog API status error exceptions."""

    def retried_func(self, *args, **kwargs):
        tries = 0
        while True:
            resp, tries, should_continue = attempt_api_call(func, self.log, tries, args, kwargs)
            if not should_continue:
                return resp

    return retried_func


class DatadogClient:
    def __init__(self, instance_check: object):
        """Initializes DatadogClient object with API key.

        :param instance_check: instance check object
        :type instance_check: object
        """
        site = instance_check._site
        api_key = {
            "apiKeyAuth": instance_check._api_key,
            "appKeyAuth": instance_check._app_key,
        }

        api_configuration = Configuration(host=constants.API_SITE.format(site), api_key=api_key)
        log_api_config = Configuration(host=constants.LOGS_INTAKE_SITE.format(site), api_key=api_key)

        # Set proxy settings
        if instance_check.proxy_url:
            api_configuration.proxy = instance_check.proxy_url
            log_api_config.proxy = instance_check.proxy_url
            if instance_check.proxy_username and instance_check.proxy_password:
                proxy_auth_header = make_headers(
                    proxy_basic_auth=f"{instance_check.proxy_username}:{instance_check.proxy_password}"
                )
                api_configuration.proxy_headers = proxy_auth_header
                log_api_config.proxy_headers = proxy_auth_header

        self.api_client = ApiClient(api_configuration)
        self.log_client = ApiClient(log_api_config)

        self.instance_check = instance_check
        self.cluster_name = instance_check.cluster_name
        self.host = instance_check.host
        self.username = instance_check.username
        self.parsed_username = replace_special_char_with_underscore(str_to_change=self.username)
        self.log = instance_check.log

    def close(self):
        """DatadogClient object destructor."""
        self.api_client.close()
        self.log_client.close()

    def validate_api_key(self) -> None:
        """Validates API key and raises error if it is invalid.

        :raises InvalidAPIKeyError: raised when api key validation fails.
        """
        try:
            auth_api = AuthenticationApi(self.api_client)
            response = auth_api.validate()

            if response.get("valid") is True:
                success_msg = "Connection with datadog is successful."
                self.log.info(success_msg)
            else:
                err_message = f"Something went wrong while validating Datadog API key: {response}"
                self.log.error(err_message)
                raise InvalidAPIKeyError(err_message)

        except ForbiddenException as err:
            forbidden_msg = "Datadog API key validation failed. Verify the configured API key."
            self.log.error(forbidden_msg)
            raise InvalidAPIKeyError(forbidden_msg) from err

        except Exception:
            err_message = "Error occurred while validating datadog API key."
            self.log.exception(err_message)
            raise

    def validate_keys(self) -> None:
        """Validates api key and app key.

        :raises InvalidKeyError: raised when api key or app key validation fails.
        """
        try:
            current_time = time.time()
            past_1_hour = current_time - 3600
            params = {
                "from": utc_time_from_timestamp(past_1_hour),
                "to": utc_time_from_timestamp(current_time),
            }
            self.search_log_in_datadog(self.instance_check.log_index, **params)

            success_msg = "Connection with datadog is successful."
            self.log.info(success_msg)

        except InvalidKeyError as err:
            forbidden_msg = "Datadog api/app key validation failed. Verify the configured api key and app key."
            self.log.error(forbidden_msg)
            raise InvalidKeyError(forbidden_msg) from err

        except Exception:
            err_message = "Error occurred while validating datadog api/app key."
            self.log.exception(err_message)
            raise

    def create_chunks_for_events(
        self,
        events: List,
        chunk_size_limit: int,
        chunk_length_limit: Union[int, None] = 1000,
    ) -> Iterator:
        """Creates chunks of events to handle Datadog API restrictions.

        :param events: list of events
        :type events: list
        :param chunk_size_limit: maximum size of chunks
        :type chunk_size_limit: int
        :param chunk_length_limit: maximum length of chunks
        :type chunk_length_limit: Union[int, None]

        :return: list of chunks of events
        :rtype: Generator
        """
        chunk = []
        buffer_size = 0
        for event in events:
            size_of_event = len(json.dumps(event, default=str).encode("utf-8"))
            if (buffer_size + size_of_event) > chunk_size_limit or (
                chunk_length_limit is not None and len(chunk) >= chunk_length_limit
            ):
                yield chunk
                chunk = []
                buffer_size = 0
            chunk.append(event)
            buffer_size += size_of_event
        if len(chunk) > 0:
            yield chunk

    def submit_metrics(
        self,
        metrics_list: List[Tuple],
        latest: bool = False,
        include_prefix: bool = True,
    ) -> None:
        """Submits metrics to the Datadog.

        :param metrics_list: list of metrics tuples. Index wise breakdown of tuples
            of metrics properties is as following.
                0: metrics name
                1: metrics value
                2: list of metrics tags
                3: metrics timestamp
        :type metrics_list: List[Tuple]
        :param latest: flag to indicate whether current timestamp should be used
            as a metrics timestamp. Defaults to False.
        :type latest: bool
        :param include_prefix: indicate whether constant metric prefix should be
            added to metric name
        :type include_prefix: bool
        """
        metrics_series = []
        submitted_metrics_count = 0
        for metrics in metrics_list:
            # add host and username as tags
            metrics_series.append(
                {
                    "metric": (constants.INTEGRATION_PREFIX + metrics[0]) if include_prefix else metrics[0],
                    "type": "gauge",
                    "points": [[metrics[3] if not latest else int(time.time()), metrics[1]]],
                    "tags": metrics[2],
                    "host": self.host,
                }
            )

        chunks = self.create_chunks_for_events(metrics_series, constants.METRICS_MAX_CHUNK_SIZE)
        for chunk in chunks:
            metrics_body = {"series": chunk}
            metrics_api = MetricsApi(self.api_client)
            try:
                submit_metrics_with_retry = retry_on_api_exception(metrics_api.submit_metrics)
                response = submit_metrics_with_retry(self, metrics_body, content_encoding=MetricContentEncoding.GZIP)
                if response.get("status") == "ok":
                    submitted_metrics_count += len(chunk)
                else:
                    self.log.error(f"Something went wrong while submitting metrics. Response: {response}")  # noqa: G004
            except ApiException as err:
                self.log.exception(f"API error occurred while submitting metrics: {err}")  # noqa: G004
                raise
        self.log.info(
            f"{submitted_metrics_count}/{len(metrics_list)}"  # noqa: G004
            " metrics are ingested into Datadog platform."
        )

    def submit_logs(
        self,
        service: str,
        events: List,
        timestamp_field: str = None,
        fn_to_evaluate_event: Callable = None,
    ) -> None:
        """Submits logs to the Datadog.

        :param service: service name of the log.
        :type service: str
        :param events: list of events
        :type events: List
        :param timestamp_field: name of the timestamp field from events data. Defaults to None.
        :type timestamp_field: str
        :param fn_to_evaluate_event: function that will return events and tags list from events data. Defaults to None.
        :type: Callable
        """
        ingested_logs_count = 0
        # add integration prefix to service name
        service = constants.INTEGRATION_PREFIX + service
        api_instance = LogsApi(self.log_client)
        chunks = self.create_chunks_for_events(events, constants.LOGS_MAX_CHUNK_SIZE, constants.LOGS_MAX_CHUNK_LENGTH)
        for chunk in chunks:
            body_items = self._prepare_body(service, chunk, timestamp_field, fn_to_evaluate_event)
            body = body_items
            try:
                # Send logs
                submit_log_with_retry = retry_on_api_exception(api_instance.submit_log)
                submit_log_with_retry(self, body, content_encoding=ContentEncoding.GZIP)
                ingested_logs_count += len(chunk)
            except ApiException as err:
                self.log.exception(f"API error occurred while submitting logs: {err}")  # noqa: G004
                raise
        self.log.info(
            f"{ingested_logs_count}/{len(events)} Logs"  # noqa: G004
            f" are ingested into Datadog platform with service: '{service}'",
        )

    def _prepare_body(
        self,
        service: str,
        events: List,
        timestamp_field: str = None,
        fn_to_evaluate_event: Callable = None,
    ) -> List:
        """Prepares body of events to ingest as logs.

        :param service: service name of the log.
        :type service: str
        :param events: list of events
        :type events: List
        :param timestamp_field: name of the timestamp field from events data. Defaults to None.
        :type timestamp_field: str
        :param fn_to_evaluate_event: function that will return events and tags list from events data. Defaults to None.
        :type: func

        :return: list of prepare logs
        :rtype: List
        """
        http_log_items = []
        tags = ", ".join(self.instance_check.instance.get("tags", []))

        for event in events:
            evaluated_tags = []
            if fn_to_evaluate_event:
                event, evaluated_tags = fn_to_evaluate_event(event)

            # add custom timestamp from event as a ingestion time
            if timestamp_field:
                event["timestamp"] = utc_time_from_timestamp(event.get(timestamp_field))

            # add cluster attribute to every logs
            if self.cluster_name:
                event["cluster"] = self.cluster_name

            http_log_items.append(
                {
                    "ddsource": constants.SOURCE_TYPE_NAME,
                    "ddtags": tags + ("," + ",".join(evaluated_tags) if evaluated_tags else ""),
                    "hostname": self.cluster_name,
                    "message": json.dumps(event, default=str),
                    "service": service,
                }
            )
        return http_log_items

    def search_log_in_datadog(self, index, query="", **kwargs) -> List:
        """Searches log data with query.

        :param index: log index name
        :type index: str
        :param query: search query string
        :type query: str

        :return: searched log data
        :rtype: List
        """
        api_instance = LogsApi(self.api_client)
        filter_query = query
        filter_index = index
        filter_from = dateutil_parser(kwargs.get("from"))
        filter_to = dateutil_parser(kwargs.get("to"))
        sort = LogsSort("-timestamp")
        try:
            try:
                # Get a list of logs
                list_logs_get_with_retry = retry_on_api_exception(api_instance.list_logs_get)
                api_response = list_logs_get_with_retry(
                    self,
                    filter_query=filter_query,
                    sort=sort,
                    filter_from=filter_from,
                    filter_to=filter_to,
                    page_limit=1,
                )
                return api_response
            except TypeError:
                ver_message = "TypeError while searching logs, using older datadog-api-client version."
                self.log.debug(ver_message)
                api_response = list_logs_get_with_retry(
                    filter_query=filter_query,
                    filter_index=filter_index,
                    sort=sort,
                    filter_from=filter_from,
                    filter_to=filter_to,
                    page_limit=1,
                )
            return api_response
        except ApiException as err:
            if (
                err.status == 400
                and err.body
                and isinstance(err.body, dict)
                and err.body.get("errors") == constants.NO_LOG_ERROR_MESSAGE
            ):
                err_message = (
                    "Received 'no valid index specified' error while searching logs, which indicates no logs"
                    " are present in the Datadog platform at the moment so returning empty log dictionary."
                )
                self.log.info(err_message)
                return constants.EMPTY_SEARCH_LOG
            self.log.exception(f"Could not search log in Datadog with query filter: {filter_query}.")  # noqa: G004
            raise

    def save_checkpoint(self, name: str, data: Dict) -> None:
        """Saves checkpoint as a datadog log with host and endpoint.

        :param name: checkpoint name
        :type name: str
        :param data: checkpoint data
        :type data: dict
        """
        self.log.info(f"Proceeding to save checkpoint with name '{name}'")  # noqa: G004

        def checkpoint_event_evaluator(event: dict):
            return event.get("event"), event.get("tags")

        data["timestamp"] = int(time.time())
        checkpoint = [
            {
                "event": data,
                "tags": [],
            }
        ]
        self.submit_logs(
            name,
            checkpoint,
            "timestamp",
            fn_to_evaluate_event=checkpoint_event_evaluator,
        )
        self.log.info(f"Checkpoint saved with name '{name}'. Saved checkpoint: {checkpoint}")  # noqa: G004

    def get_checkpoint(self, name: str, search_cluster: bool = True, raise_error: bool = True) -> Dict:
        """Fetches and returns checkpoint log from datadog.

        :param name: checkpoint name
        :type name: str
        :param search_cluster: True if logs should be searched by cluster else False, defaults to True
        :type search_cluster: bool
        :param raise_error: whether error should be raised or ignored, defaults to True
        :type raise_error: bool

        :return: checkpoint dictionary
        :rtype: dict
        """
        self.log.info(f"Proceeding to fetch checkpoint of '{name}'.")  # noqa: G004
        now_time = datetime.now(timezone.utc)
        from_time = now_time - timedelta(seconds=constants.CHECKPOINT_TIME_OFFSET)
        now_time_str = now_time.strftime(constants.LOGS_TIME_FORMAT)
        from_time_str = from_time.strftime(constants.LOGS_TIME_FORMAT)

        kwargs = {"from": from_time_str, "to": now_time_str}
        filter_query = "service:{}{}".format(constants.INTEGRATION_PREFIX, name)
        self.instance_check.log.info(filter_query)
        if search_cluster:
            filter_query += f" {constants.INTEGRATION_PREFIX}cluster:{self.cluster_name}"
        try:
            response = self.search_log_in_datadog(
                index=self.instance_check.log_index,
                query=filter_query,
                **kwargs,
            )

            # if data parse the result, we will return last checkpoint log
            response_dict = response.to_dict()
            if len(response_dict["data"]) > 0:
                checkpoint_data = response_dict["data"][0]["attributes"]["attributes"]
                return checkpoint_data
        except Exception:
            self.log.exception(f"Could not get the checkpoint log of '{name}' from datadog platform.")  # noqa: G004
            if raise_error:
                raise
        return {}
