"""Module for NFS Export Stats"""

from .cds_dell_emc_consts import INTEGRATION_PREFIX, REQUEST_FAILED_MESSAGE


class CDSDellEMCNFSExportStatsHelper(object):
    """Class for NFS Export Stats"""

    def __init__(self, instance: object):
        self.nfs_export_stats_prefix = "{}{}".format(INTEGRATION_PREFIX, "nfs_export_stats_details.")
        self.instance = instance

    def filter_datasets_by_ids(self, datasets):
        self.instance.dataset_list = [x.strip() for x in self.instance.dataset_ids.split(",")]
        self.instance.dataset_list = list(filter(None, self.instance.dataset_list))
        for dataset_dict in datasets:
            for dataset in self.instance.dataset_list:
                if str(dataset_dict["id"]) == dataset and "export_id" in dataset_dict["metrics"]:
                    self.instance.valid_dataset.append(dataset)

    def filter_valid_datasets(self, datasets):
        self.instance.valid_dataset = []
        if self.instance.dataset_ids:
            self.filter_datasets_by_ids(datasets)
        else:
            for dataset in datasets:
                if "export_id" in dataset.get("metrics", []):
                    self.instance.valid_dataset.append(str(dataset.get("id")))

    def validate_datasets(self):
        url = f"{self.instance.base_uri}/platform/14/performance/datasets"
        response_json = None
        try:
            response_json = self.instance._make_request(url)
        except Exception as exception:
            self.instance.log.exception(exception)
            raise exception

        if response_json is None:
            self.instance.log.error("%s %s", REQUEST_FAILED_MESSAGE, url)
            raise Exception("%s %s", REQUEST_FAILED_MESSAGE, url)

        datasets = response_json.get("datasets", [])
        if not datasets:
            self.instance.log.error("No datasets found for : %s", url)
            raise Exception("No datasets found for : %s", url)

        self.filter_valid_datasets(datasets)

        if not self.instance.valid_dataset:
            self.instance.log.error("No datasets found having metrics: export_id")
            raise ValueError("No datasets found having metrics: export_id")

    def build_export_path_map(self):
        url = f"{self.instance.base_uri}/platform/14/protocols/nfs/exports"
        response_json = None
        try:
            response_json = self.instance._make_request(url)
        except Exception as exception:
            self.instance.log.exception(exception)
            raise exception

        if response_json is None:
            self.instance.log.error("%s %s", REQUEST_FAILED_MESSAGE, url)
            raise Exception("%s %s", REQUEST_FAILED_MESSAGE, url)

        exports = response_json.get("exports", [])
        if not exports:
            self.instance.log.error("No exports found for : %s", url)
            raise Exception("No exports found for : %s", url)
        export_path_map = {}
        export_zone_map = {}
        if not self.instance.export_ids:
            for export in exports:
                export_path_map.update({str(export.get("id")): export.get("paths", [])})
                export_zone_map.update({str(export.get("id")): export.get("zone")})
        else:
            self.instance.export_list = [x.strip() for x in self.instance.export_ids.split(",")]
            self.instance.export_list = list(filter(None, self.instance.export_list))
            for export in self.instance.export_list:
                export_path_map.update(
                    {export: export_path["paths"] for export_path in exports if export == str(export_path["id"])}
                )
                export_zone_map.update(
                    {export: export_path["zone"] for export_path in exports if export == str(export_path["id"])}
                )
            if not export_path_map:
                self.instance.log.error("No such exports found. Please provide valid export_ids.")
                raise ValueError("No exports found. Please provide valid export_ids.")
        return export_path_map, export_zone_map

    def fetch_response_stats(self, api, export_path_map):
        response_stats = []
        for id in self.instance.valid_dataset:
            url = (
                f"{self.instance.base_uri}{api.get('api_url', '')}?dataset={id}&export_ids"
                f"={','.join(export_path_map.keys())}"
            )
            try:
                response = self.instance._make_request(url)
            except Exception as exception:
                self.instance.log.exception(exception)
                raise exception

            if response is None:
                self.instance.log.error("Request Failed of url : %s", url)
                continue
            response_data = response.get("workload", [])
            for response_dict in response_data:
                response_dict.update({"dataset_id": id, "cluster_name": self.instance.cluster_name})
            response_stats.extend(response_data)
        return response_stats

    def get_stats_and_export_path_map(self, api):
        self.validate_datasets()
        export_path_map, export_zone_map = self.build_export_path_map()
        response_stats = self.fetch_response_stats(api, export_path_map)
        return response_stats, export_path_map, export_zone_map

    def ingest_stats_params(self, api):
        response_stats, export_path_map, export_zone_map = self.get_stats_and_export_path_map(api)

        cds_dell_emc_helper_class_ = self.instance.get_helper_class(api)
        for panel in api.get("dashboard_panels", []):
            panel_to_call = getattr(cds_dell_emc_helper_class_(self), panel)
            if panel_to_call is not None:
                try:
                    metrics_list = panel_to_call(response_stats, export_path_map, export_zone_map)
                    for metric in metrics_list:
                        tags = metric[2] + self.instance._tags
                        self.instance.gauge(metric[0], metric[1], tags=tags)
                except Exception as exception:
                    error = "Error occurred while ingesting the data of {} panel.".format(panel)
                    self.instance.log.exception(error)
                    raise exception

                self.instance.log.info("Data for %s panel is ingested successfully.", panel)

    def nfs_export_bytes_in(self, response_stats, export_path_map, export_zone_map):
        """Method to get NFS Export Bytes In Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, export_zone_map, "bytes_in")
        return metrics_list

    def nfs_export_bytes_out(self, response_stats, export_path_map, export_zone_map):
        """Method to get NFS Export Bytes Out Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, export_zone_map, "bytes_out")
        return metrics_list

    def nfs_export_latency_read(self, response_stats, export_path_map, export_zone_map):
        """Method to get NFS Export Latency Read Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, export_zone_map, "latency_read")
        return metrics_list

    def nfs_export_latency_write(self, response_stats, export_path_map, export_zone_map):
        """Method to get NFS Export Latency Write Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, export_zone_map, "latency_write")
        return metrics_list

    def nfs_export_reads(self, response_stats, export_path_map, export_zone_map):
        """Method to get NFS Export Reads Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, export_zone_map, "reads")
        return metrics_list

    def nfs_export_ops(self, response_stats, export_path_map, export_zone_map):
        """Method to get NFS Export Ops Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, export_zone_map, "ops")
        return metrics_list

    def nfs_export_cpu(self, response_stats, export_path_map, export_zone_map):
        """Method to get NFS Export CPU Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, export_zone_map, "cpu")
        return metrics_list

    def nfs_export_writes(self, response_stats, export_path_map, export_zone_map):
        """Method to get NFS Export Writes Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, export_zone_map, "writes")
        return metrics_list

    def create_metrics(self, response_stats, export_path_map, export_zone_map, key):
        metric_prefix = "{}{}".format(self.nfs_export_stats_prefix, key)
        metric_list = []
        for export_stats in response_stats:
            stats_value = export_stats.get(key)
            export_id = export_stats.get("export_id")
            if export_id is None:
                continue
            metric_list.append(
                [
                    metric_prefix,
                    stats_value,
                    [
                        f"{INTEGRATION_PREFIX}export_id:{export_id}",
                        f"{INTEGRATION_PREFIX}path:{export_path_map.get(str(export_id))}",
                        f"{INTEGRATION_PREFIX}dataset_id:{export_stats.get('dataset_id')}",
                        f"{INTEGRATION_PREFIX}node:node-{export_stats.get('node')}",
                        f"{INTEGRATION_PREFIX}cluster:{export_stats.get('cluster_name')}",
                        f"{INTEGRATION_PREFIX}zone:{export_zone_map.get(str(export_id))}",
                    ],
                ]
            )

        return metric_list
